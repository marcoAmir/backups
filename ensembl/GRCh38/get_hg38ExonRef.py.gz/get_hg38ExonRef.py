#!/usr/bin/env python

import sys
import math

def parseBed12(input_bed12):
	outfile = open('hg38.exonAlignments.bed.ref', 'w')
	with open(input_bed12) as bed12:
		for line in bed12:
			residue = 1
			codingBP = 0
			transcript_data = line.strip().split()
			cdsStart = int(transcript_data[1])
			exonBlocks = transcript_data[10].split(',')
			strtBlocks = transcript_data[11].split(',')
			exonBlocks.pop()
			strtBlocks.pop()
			for i in range(0, len(exonBlocks)):
				exonRes = transcript_data[3] + '.exon.' + str(i+1) + '.hg38.residues.' + str(residue) + '-'
				if( transcript_data[5]=="+" ):
					codingBP += int(exonBlocks[i])
				if( transcript_data[5]=="-" ):
					codingBP += int(exonBlocks[len(exonBlocks) - i - 1])
				residue = math.trunc(float(codingBP)/3)
				if( int(codingBP)%3>0 ):
					exonRes = exonRes + str(residue + 1)
				else:
					exonRes = exonRes + str(residue)
				residue += 1
				if( transcript_data[5]=="+" ):
					currStart = cdsStart + int(strtBlocks[i])
					currEnd = cdsStart + int(strtBlocks[i]) + int(exonBlocks[i])
				if( transcript_data[5]=="-" ):
					currStart = cdsStart + int(strtBlocks[len(exonBlocks) - i - 1])
					currEnd = cdsStart + int(strtBlocks[len(exonBlocks) - i - 1]) + int(exonBlocks[len(exonBlocks) - i - 1])
				outfile.write("\t".join([transcript_data[0],
					  str(currStart - 6),	# for some reason, the original file for hg19 has flanks of 6bp
					  str(currEnd + 6),	# for some reason, the original file for hg19 has flanks of 6bp	
					  exonRes,
					  transcript_data[4],
					  transcript_data[5],
					  ])
						+ "\n")
	outfile.close()	

if __name__ == "__main__":
	input_bed12 = sys.argv[1]
	parseBed12(input_bed12)
   

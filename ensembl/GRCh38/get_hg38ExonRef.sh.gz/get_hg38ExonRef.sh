#!/bin/bash -e

cat transcriptCoding.hg38Ens86.bed | awk -F'\t' '{
printf $1"\t"$7"\t"$8"\t"$4"\t"$5"\t"$6"\t"$7"\t"$8"\t"$9"\t"; 
split($11,a,","); 
split($12,b,","); 
nCodingExons[1]=0;
blocks[1]="";
starts[1]=""; 
for(i=1; i<=length(a); i++) {
startBlock=$2+b[i]; 
endBlock=$2+a[i]+b[i]; 
if(startBlock>=$7 && endBlock<=$8 && startBlock!=endBlock){
nCodingExons[1]+=1;
blocks[1]=blocks[1] a[i] "," 
starts[1]=starts[1] b[i]+$2-$7 ","
}
if(startBlock<$7 && endBlock<=$8 && endBlock>$7){
nCodingExons[1]+=1; 
blocks[1]=blocks[1] a[i]-$7+$2+b[i] ","
starts[1]=starts[1] 0 ","
}
if(startBlock>=$7 && endBlock>$8 && startBlock<$8){
nCodingExons[1]+=1; 
blocks[1]=blocks[1] $8-$2-b[i] ","
starts[1]=starts[1] b[i]+$2-$7 ","
}
if(startBlock<$7 && endBlock>$8 && startBlock!=endBlock){
nCodingExons[1]+=1; 
blocks[1]=blocks[1] $8-$7 ","
starts[1]=starts[1] 0 ","
}
}
print nCodingExons[1]"\t"blocks[1]"\t"starts[1]
}' | awk -F'\t' '{if($10>0) print $0}' > transcriptExonsCodingBases.bed

 ./get_hg38ExonRef.py transcriptExonsCodingBases.bed

